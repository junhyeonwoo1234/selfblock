import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const ch = MethodChannel('selfblock');
const failMsgs = [
  '오늘 한 번 무너지면, 내일의 기준도 함께 낮아져요.',
  "목표를 포기한 날은 '다음에 하지 뭐'로 기록되기 쉬워요.",
  '지금 느끼는 충동은 보통 10분이면 지나가요.',
  '나와 한 약속을 깨면, 다음 약속은 더 믿기 어려워져요.',
  '연속 기록이 끊기면 처음부터 다시 시작해야 해요.',
];

String two(int n) => n.toString().padLeft(2, '0');
String fmt(int ms) {
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  return '${d.month}/${d.day} ${two(d.hour)}:${two(d.minute)}';
}

void main() => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const Home(),
    ));

/// secs초 동안 누르고 있어야 실행. 누르는 동안 목표 실패 관련 글이 3초마다 바뀜
class HoldButton extends StatefulWidget {
  final String label;
  final int secs;
  final VoidCallback onDone;
  const HoldButton({Key? key, required this.label, required this.secs, required this.onDone}) : super(key: key);
  @override
  State<HoldButton> createState() => _HoldState();
}

class _HoldState extends State<HoldButton> {
  Timer? t;
  int left = 0;
  bool holding = false;

  void start() {
    left = widget.secs;
    setState(() => holding = true);
    t = Timer.periodic(const Duration(seconds: 1), (_) {
      left--;
      if (left <= 0) {
        stop();
        widget.onDone();
      } else {
        setState(() {});
      }
    });
  }

  void stop() {
    t?.cancel();
    if (mounted) setState(() => holding = false);
  }

  @override
  void dispose() {
    t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final idx = ((widget.secs - left) ~/ 3).clamp(0, failMsgs.length - 1);
    return Column(children: [
      if (holding)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Text(failMsgs[idx], textAlign: TextAlign.center, style: const TextStyle(fontSize: 17)),
        ),
      Listener(
        onPointerDown: (_) => start(),
        onPointerUp: (_) => stop(),
        onPointerCancel: (_) => stop(),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
              color: holding ? Colors.red.shade100 : Colors.grey.shade300, borderRadius: BorderRadius.circular(12)),
          child: Center(child: Text(holding ? '$left초...' : '${widget.label} (${widget.secs}초간 꾹 누르기)')),
        ),
      ),
    ]);
  }
}

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  Map<String, dynamic> s = {};
  bool admin = false;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    load();
    timer = Timer.periodic(const Duration(seconds: 20), (_) => load());
  }

  @override
  void dispose() {
    timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (st == AppLifecycleState.paused) admin = false; // 앱을 나가면 관리자 패널 닫힘
    if (st == AppLifecycleState.resumed) load();
  }

  Future<void> load() async {
    final r = await ch.invokeMethod<String>('state');
    if (!mounted || r == null) return;
    setState(() => s = Map<String, dynamic>.from(jsonDecode(r)));
  }

  Future<void> run(String m, [Map<String, dynamic>? a]) async {
    final r = await ch.invokeMethod(m, a);
    if (r is String && r.isNotEmpty) toast(r);
    await load();
  }

  void toast(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  // ---------- 공통 다이얼로그 ----------
  Future<int?> choose(String title, List<String> items) => showDialog<int>(
      context: context,
      builder: (c) => SimpleDialog(title: Text(title), children: [
            for (var i = 0; i < items.length; i++)
              SimpleDialogOption(onPressed: () => Navigator.pop(c, i), child: Text(items[i])),
          ]));

  Future<bool> confirm(String msg) async =>
      await showDialog<bool>(
          context: context,
          builder: (c) => AlertDialog(content: Text(msg), actions: [
                TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('취소')),
                TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('확인')),
              ])) ??
      false;

  Future<void> ask(String msg, Future<void> Function() f) async {
    if (await confirm(msg)) await f();
  }

  Future<Set<int>?> pickDays() {
    final on = <int>{};
    return showDialog<Set<int>>(
        context: context,
        builder: (c) => StatefulBuilder(
            builder: (c, ss) => AlertDialog(
                  title: const Text('요일 선택'),
                  content: Wrap(spacing: 6, children: [
                    for (var i = 0; i < 7; i++)
                      FilterChip(
                          label: Text('일월화수목금토'[i]),
                          selected: on.contains(i + 1),
                          onSelected: (v) => ss(() {
                                if (v) {
                                  on.add(i + 1);
                                } else {
                                  on.remove(i + 1);
                                }
                              })),
                  ]),
                  actions: [TextButton(onPressed: () => Navigator.pop(c, on), child: const Text('다음'))],
                )));
  }

  Future<int?> pickTime(String title, int hour) async {
    final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: hour, minute: 0), helpText: title);
    return t == null ? null : t.hour * 60 + t.minute;
  }

  Future<List<dynamic>> appList() async => jsonDecode(await ch.invokeMethod<String>('apps') ?? '[]') as List;

  Future<List<String>?> pickApps() async {
    final apps = await appList();
    final on = <String>{};
    if (!mounted) return null;
    return showDialog<List<String>>(
        context: context,
        builder: (c) => StatefulBuilder(
            builder: (c, ss) => AlertDialog(
                  title: const Text('스케줄 중에도 허용할 앱'),
                  content: SizedBox(
                      width: double.maxFinite,
                      height: 400,
                      child: ListView(children: [
                        for (final a in apps)
                          CheckboxListTile(
                              title: Text(a['label'] as String),
                              value: on.contains(a['pkg']),
                              onChanged: (v) => ss(() {
                                    final p = a['pkg'] as String;
                                    if (v == true) {
                                      on.add(p);
                                    } else {
                                      on.remove(p);
                                    }
                                  })),
                      ])),
                  actions: [TextButton(onPressed: () => Navigator.pop(c, on.toList()), child: const Text('저장'))],
                )));
  }

  // ---------- 기능 흐름 ----------
  Future<void> addFlow() async {
    final i = await choose('프리셋', ['수면 (매일 23:00~07:00)', '공부 (월~금 19:00~22:00)', '집중 (월~금 09:00~18:00)', '직접 설정']);
    if (i == null) return;
    Set<int> days = {};
    int st = 0, en = 0;
    if (i == 0) {
      days = {1, 2, 3, 4, 5, 6, 7};
      st = 23 * 60;
      en = 7 * 60;
    } else if (i == 1) {
      days = {2, 3, 4, 5, 6};
      st = 19 * 60;
      en = 22 * 60;
    } else if (i == 2) {
      days = {2, 3, 4, 5, 6};
      st = 9 * 60;
      en = 18 * 60;
    } else {
      final d = await pickDays();
      if (d == null || d.isEmpty) return;
      final a = await pickTime('시작 시간', 9);
      if (a == null) return;
      final b = await pickTime('종료 시간', 22);
      if (b == null) return;
      days = d;
      st = a;
      en = b;
    }
    final p = await choose('장소 제한', ['제한 없음', '지금 있는 곳(300m)에서만']);
    if (p == null) return;
    final allowed = await pickApps();
    if (allowed == null) return;
    await run('addSchedule', {'days': days.toList(), 'start': st, 'end': en, 'allowed': allowed, 'place': p == 1});
  }

  Future<void> limitFlow() async {
    if (s['usage'] != true) {
      toast("먼저 '사용 기록 권한'을 허용하세요");
      return;
    }
    final apps = await appList();
    final i = await choose('제한할 앱', [for (final a in apps) a['label'] as String]);
    if (i == null) return;
    const mins = [30, 60, 90, 120, 180];
    final j = await choose('하루 사용 한도', [for (final m in mins) '$m분']);
    if (j == null) return;
    await run('setLimit', {'pkg': apps[i]['pkg'], 'min': mins[j]});
  }

  Future<void> excFlow(bool force) async {
    final first = DateTime.now().add(Duration(days: force ? 0 : 1));
    final d = await showDatePicker(
        context: context, initialDate: first, firstDate: first, lastDate: first.add(const Duration(days: 730)));
    if (d == null) return;
    await run('addException', {'ms': DateTime(d.year, d.month, d.day).millisecondsSinceEpoch, 'force': force});
  }

  Future<void> unlockFlow() async {
    final i = await choose('얼마나 해제할까요?', ['30분', '1시간', '3시간', '오늘 하루 (자정까지)']);
    if (i == null) return;
    final n = DateTime.now();
    final ms = [30 * 60000, 3600000, 3 * 3600000, DateTime(n.year, n.month, n.day + 1).difference(n).inMilliseconds][i];
    await run('unlock', {'ms': ms});
  }

  // ---------- 화면 ----------
  String status() {
    final until = s['until'] as int;
    if (until > DateTime.now().millisecondsSinceEpoch) return '🔓 관리자 해제 중 (${fmt(until)}까지)';
    if (s['active'] == true) return '🔒 스케줄 실행 중\n${s['activeLabel']}';
    return '스케줄 없음 (자유 시간)';
  }

  String limText(Map l) {
    var t = '${l['label']} 하루 ${l['min']}분';
    if ((l['used'] as int) >= 0) t += ' · 오늘 ${l['used']}분 사용';
    if ((l['del'] as int) > 0) t += '\n⏳ 해제 예약: ${fmt(l['del'] as int)}';
    return t;
  }

  Widget head(String t) => Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 6), child: Text(t, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)));
  Widget btn(String t, VoidCallback f) =>
      Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: FilledButton.tonal(onPressed: f, child: Text(t)));

  List<Widget> mainView() {
    final sch = s['sch'] as List, lim = s['lim'] as List, exc = s['exc'] as List;
    String on(bool b) => b ? '켜짐' : '꺼짐';
    return [
      Text(status(), style: const TextStyle(fontSize: 18)),
      const SizedBox(height: 6),
      Text('홈 화면 회색 처리: ${on(s['launcher'] == true)} · 삭제 방지: ${on(s['protect'] == true)}'),
      const SizedBox(height: 12),
      Text(s['report'] as String),
      if (s['launcher'] != true) btn('🏠 셀프블록을 기본 홈 앱으로 (앱 회색 처리)', () => run('openHome')),
      if (s['protect'] != true) btn('🛡 기기 관리자 켜기 (삭제 방지)', () => run('enableAdmin')),
      btn('접근성 서비스 켜기 (필수)', () => run('openAccessibility')),
      btn('사용 기록 권한 (앱 시간 제한용)', () => run('openUsage')),
      head('스케줄'),
      btn('＋ 스케줄 추가', addFlow),
      for (var i = 0; i < sch.length; i++)
        ListTile(
          title: Text(sch[i]['label'] as String),
          subtitle: Text(sch[i]['pending'] == true ? '길게 눌러 예약 취소' : '길게 눌러 삭제 예약 (24시간 후 적용)'),
          onLongPress: () => ask(sch[i]['pending'] == true ? '삭제 예약을 취소할까요?' : '24시간 뒤 삭제되도록 예약할까요?',
              () => run('toggleDelSchedule', {'i': i})),
        ),
      head('앱별 하루 사용 한도'),
      btn('＋ 앱 시간 제한 추가', limitFlow),
      for (final l in lim)
        ListTile(
          title: Text(limText(l)),
          subtitle: Text((l['del'] as int) > 0 ? '길게 눌러 예약 취소' : '길게 눌러 해제 예약 (24시간 후)'),
          onLongPress: () => ask((l['del'] as int) > 0 ? '해제 예약을 취소할까요?' : '24시간 뒤 한도가 해제되도록 예약할까요?',
              () => run('toggleDelLimit', {'pkg': l['pkg']})),
        ),
      head('예외 날짜 (스케줄 쉬는 날)'),
      btn('＋ 예외 날짜 추가 (24시간 이후만)', () => excFlow(false)),
      for (final e in exc)
        ListTile(title: Text(e as String), subtitle: const Text('길게 눌러 삭제'), onLongPress: () => run('removeException', {'k': e})),
      const SizedBox(height: 24),
      HoldButton(label: '🛠 관리자 패널', secs: 15, onDone: () => setState(() => admin = true)),
    ];
  }

  List<Widget> adminView() {
    final sch = s['sch'] as List, lim = s['lim'] as List, exc = s['exc'] as List;
    final locked = (s['until'] as int) > DateTime.now().millisecondsSinceEpoch;
    return [
      const Text('여기서의 변경은 대기 시간 없이 즉시 적용돼요.'),
      const SizedBox(height: 6),
      Text(status(), style: const TextStyle(fontSize: 18)),
      btn('🔓 즉시 잠금 해제', unlockFlow),
      if (locked) btn('🔒 다시 잠금', () => run('relock')),
      head('스케줄 (눌러서 삭제 · 변경은 삭제 후 추가)'),
      btn('＋ 스케줄 추가', addFlow),
      for (var i = 0; i < sch.length; i++)
        btn(sch[i]['label'] as String, () => ask('이 스케줄을 삭제할까요?', () => run('deleteSchedule', {'i': i}))),
      head('앱 시간 한도 (눌러서 즉시 해제)'),
      for (final l in lim) btn('${l['label']} 하루 ${l['min']}분', () => run('removeLimit', {'pkg': l['pkg']})),
      head('예외 날짜 (눌러서 삭제)'),
      btn('＋ 예외 날짜 추가 (날짜 제한 없음)', () => excFlow(true)),
      for (final e in exc) btn(e as String, () => run('removeException', {'k': e})),
      head('기타'),
      btn('📊 기록 초기화', () => ask('차단 기록과 연속 일수를 초기화할까요?', () => run('resetLog'))),
      btn('🗑 앱 삭제', () => ask('보호를 해제하고 앱을 삭제할까요?', () => run('uninstall'))),
      btn('관리자 패널 닫기', () => setState(() => admin = false)),
    ];
  }

  @override
  Widget build(BuildContext context) {
    if (s.isEmpty) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return WillPopScope(
      onWillPop: () async {
        if (admin) {
          setState(() => admin = false);
          return false;
        }
        return true;
      },
      child: Scaffold(
        appBar: AppBar(title: Text(admin ? '🛠 관리자 패널' : '셀프블록')),
        body: ListView(padding: const EdgeInsets.all(16), children: admin ? adminView() : mainView()),
      ),
    );
  }
}
